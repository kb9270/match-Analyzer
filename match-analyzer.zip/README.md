# Match Analyzer

Projet Python pour automatiser l'analyse d'un match de football à partir d'une vidéo (caméra fixe).